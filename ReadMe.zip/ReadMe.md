Php Project mysql auto install script

Professional modern ui layiut design
Interactive buttons
With video play back

A professional Video Karaoke Player with similar functions of Actual Video Karaoke System with all the features like Buttons for songs, Queque or next song, a Realistic and actual accurate Scoring

With sound when button numbers was entering like the real video karaoke system.


The project with Professional Admin Panel for video upalods and stream link to be play. Accept direct link, upload, Youtibe link and other vidoe formats.


Project consst the following interface


Songlist with song numbers auto generate 6 digit numbers the reflect from the admin panel

Video Playback 
which is the site that the user play and sing a song, make sure it will automatically play like the actual video karaoke system

Admin panels
were to add via, uplaod, link, eitehr direct or embed link, and generate a 6 digit numbers that reflect to the songlist.


